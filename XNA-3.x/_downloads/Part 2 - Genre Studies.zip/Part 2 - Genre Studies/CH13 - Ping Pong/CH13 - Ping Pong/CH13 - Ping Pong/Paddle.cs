﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CH13___Ping_Pong
{
    class Paddle : GameObject
    {
    }
}
